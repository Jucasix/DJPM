package ipca.example.dailynews.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import ipca.example.dailynews.models.Article
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class SportsViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(ArticlesState())
    val uiState: StateFlow<ArticlesState> = _uiState

    fun fetchSportsArticles() {
        viewModelScope.launch {
            // Aqui você pode buscar as notícias de desporto da sua API
            val sportsArticles = listOf(
                // Simulação de dados, substitua pela chamada da API real
                Article("Notícia Desporto 1", "Descrição Desporto 1", urlToImage = "urlImagem1"),
                Article("Notícia Desporto 2", "Descrição Desporto 2", urlToImage = "urlImagem2")
            )
            _uiState.value = ArticlesState(articles = sportsArticles, isLoading = false)
        }
    }
}
