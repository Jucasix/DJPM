package ipca.example.dailynews.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class PoliticsViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(ArticlesState())
    val uiState: StateFlow<ArticlesState> = _uiState

    fun fetchPoliticsArticles() {
        viewModelScope.launch {
            _uiState.value = ArticlesState(isLoading = true)

            try {
                val newsApi
                val articles = newsApi.getPoliticsNews()  // Supondo que a API tem essa função
                _uiState.value = ArticlesState(articles = articles)
            } catch (e: Exception) {
                _uiState.value = ArticlesState(error = e.message)
            }
        }
    }
}
